#include <stdlib.h>  /* for using the functions calloc, free */
#include <string.h>  /* for using the function memcpy        */
#include <limits.h>  /* for using the constant UINT_MAX      */
#include <stdio.h>
#define CONTEXT_SIZE    8   /*  for the 8 registers: r4 to r11   */
#define STACK_SIZE      100 /*  about enough space for the stack */


#define TRUE    1
#define FALSE   !TRUE

#define RUNNING 1
#define INIT    !RUNNING

#define FAIL    0
#define SUCCESS 1
#define OK              1

#define DEADLINE_REACHED        0
#define NOT_EMPTY               0

#define SENDER          +1
#define RECEIVER        -1


typedef int             exception;
typedef int             bool;
typedef unsigned int    uint;
typedef int 			action;


//THIS IS THE NODE
typedef struct l_obj {
        // TCB            *pTask;
         uint           nTCnt;
         //msg            *pMessage;
         struct l_obj   *pPrevious;
         struct l_obj   *pNext;
} listobj;


//THIS IS THE LIST
typedef struct _list {
         listobj        *pHead;
         listobj        *pTail;
} list;

listobj* safeAllocNode(){                   //ALLOCATE MEMORY OF NODE
  struct l_obj *node = NULL;
  node = malloc(sizeof(struct l_obj));
  if(node == NULL){
    printf("MALLOC IN NODE FAILED!\n");
    return FAIL;
  }
  return node;
}
list* safeAllocList(){
  struct _list *list = NULL;
  list = malloc(sizeof(struct _list));
  if(list == NULL){
    printf("MALLOC IN LIST FAILED!\n");
    return FAIL;
  }
  return list;
}

listobj* createNode(int prio){
  listobj *node = safeAllocNode();
  if(node == NULL){
    return FAIL;
  }
  node->pNext = NULL;
  node->pPrevious = NULL;
  node->nTCnt = prio;
  return node;
}

list* createList(){
  list *list = safeAllocList();
  if(list == NULL){
    return FAIL;
  }
  list->pHead = NULL;
  list->pTail = NULL;
  return list;
}



void* insertSorted(struct _list **list, int prio){
  struct _list *tempList = *list;
  listobj *tempNode = tempList->pHead;

  if (tempList->pHead == NULL && tempList->pTail == NULL) { //List if empty
    listobj *node = createNode(prio);
    if(node == FAIL || node == NULL){
      return FAIL;
    }
    tempList->pHead = node;
    tempList->pTail = node;
    node->pNext = NULL;
    node->pPrevious = NULL;
  }
  else if(tempList->pHead->nTCnt >= prio){                //prio in pHead is less than new node prio
    listobj *node = createNode(prio);
    if(node == FAIL || node == NULL){
      return FAIL;
    }
    node->pNext = tempList->pHead;
    tempList->pHead->pPrevious = node;
    tempList->pHead = node;
  }
  else if(tempList->pTail->nTCnt <= prio){               //prio in pTail is less than new node prio
    listobj *node = createNode(prio);
    if(node == FAIL || node == NULL){
      return FAIL;
    }
    node->pPrevious = tempList->pTail;
    tempList->pTail->pNext = node;
    tempList->pTail = node;
  }

  else{                                                       //insert new node in sorted order by prio in the middle of the list
    listobj *node = createNode(prio);
    if(node == FAIL || node == NULL){
      return FAIL;
    }
    while (tempNode->pNext != NULL && tempNode->nTCnt < prio) {
      tempNode = tempNode->pNext;
    }
    node->pPrevious = tempNode->pPrevious;
    tempNode->pPrevious->pNext = node;
    node->pNext = tempNode;
    tempNode->pPrevious = node;
  }
  return 1;
}



void* insert(struct _list **list,int prio){
  struct _list *tempList = *list;
  struct l_obj *tempNode = tempList->pHead;

  //printf("insert\n" );
  if (tempList->pHead == NULL && tempList->pTail == NULL) { //List if empty
    listobj *node = createNode(prio);
    if(node == FAIL || node == NULL){
      return FAIL;
    }
    tempList->pHead = node;
    tempList->pTail = node;
    node->pNext = NULL;
    node->pPrevious = NULL;
  }

  else{
    while (tempNode->pNext != NULL ) {
      tempNode = tempNode->pNext;
    }
    listobj *node = createNode(prio);
    if(node == FAIL || node == NULL){
      return FAIL;
    }
    tempNode->pNext = node;
    node->pPrevious = tempNode;
    node->pNext = NULL;
    tempList->pTail = node;
  }
  return 1;
}

void printListFirstToLast(struct _list **list){
  struct _list *tempList = *list;
  struct l_obj *tempNode = tempList->pHead;
  if (tempList->pHead == tempList->pTail && tempList->pTail == NULL) { //List if empty
    printf("List is empty\n");
  }
  else{
    while (tempNode->pNext != NULL ) {
      printf("%d\n",tempNode->nTCnt );     //Prints out all the prios
      tempNode = tempNode->pNext;
    }
    printf("%d\n",tempNode->nTCnt );       //Prints out the last prio
    printf("\n");
  }

}

int size(struct _list **list){
  struct _list *tempList = *list;
  struct l_obj *tempNode = tempList->pTail;
  int size = 0;

  if (tempList->pHead == tempList->pTail && tempList->pTail == NULL) { //List if empty
    return size;
  }
  else{
    while (tempNode != NULL ) {
      tempNode = tempNode->pNext;
    }
  }
  return size;
}

void deleteLastNode(struct _list **list){
  struct _list *tempList = *list;
  struct l_obj *tempNode = tempList->pTail;

  tempList->pTail = tempNode->pPrevious;
  tempList->pTail->pNext = NULL;
  tempNode->pNext = NULL;
  tempNode->pPrevious = NULL;
  free(tempNode);
}

void deleteFirstNode(struct _list **list){
  struct _list *tempList = *list;
  struct l_obj *tempNode = tempList->pHead;

  tempList->pHead = tempNode->pNext;
  tempList->pHead->pPrevious = NULL;
  tempNode->pNext = NULL;
  tempNode->pPrevious = NULL;
  free(tempNode);
}

void printListLastToFirst(struct _list **list){
  struct _list *tempList = *list;
  struct l_obj *tempNode = tempList->pTail;
  if (tempList->pHead == tempList->pTail && tempList->pTail == NULL) { //List if empty
    printf("List is empty\n");
  }
  else{
    while (tempNode->pPrevious != NULL ) {
      printf("%d\n",tempNode->nTCnt );     //Prints out all the prios
      tempNode = tempNode->pPrevious;
    }
    printf("%d\n",tempNode->nTCnt );       //Prints out the first prio
    printf("\n");
  }
}

void printpHead(struct _list **list){
  struct _list *tempList = *list;
  struct l_obj *tempNode = tempList->pHead;
  printf("%d\n", tempNode->nTCnt);
}

void printTail(struct _list **list){
  struct _list *tempList = *list;
  struct l_obj *tempNode = tempList->pTail;
  printf("%d\n", tempNode->nTCnt);
}
