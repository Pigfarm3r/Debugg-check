int Ticks; // tick counter
int KernelMode;
TCB *PreviousTask, *NextTask;
list *ReadyLis t , *WaitingList , *TimerList ;
