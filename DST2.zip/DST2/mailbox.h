#include <stdlib.h>  /* for using the functions calloc, free */
#include <string.h>  /* for using the function memcpy        */
#include <limits.h>  /* for using the constant UINT_MAX      */
#include <stdio.h>
#include "structures.h"


mailbox* safeAllocMailbox(){
  mailbox* mBox = NULL;
  mBox = malloc(sizeof(mailbox));
  if(mBox == NULL){
    printf("MALLOC IN MAILBOX!\n");
    return FAIL;
  }
  return mBox;
}

mailbox* createMailbox(msg* head, msg* tail, int dataSize, int maxMessages, int messages, int blockedMsg){
  mailbox *mBox = safeAllocMailbox();
  if(mBox == NULL || mBox == FAIL){
    return FAIL;
  }
  mBox->pHead = head;
  mBox->pTail = tail;
  mBox->nDataSize = dataSize;
  mBox->nMaxMessages = maxMessages;
  mBox->nMessages = messages;
  mBox->nBlockedMsg = blockedMsg;



  return mBox;
}

msg* createMSG(char* pDataInput,struct l_obj* pBlockInput){     //maybe add ,exception statusInput
  msg* message = safeAllocMessage();
  if(list == NULL){
    return FAIL;
  }

  message->pData = pDataInput;
  //message->Status = statusInput
  message->pBlock = pBlockInput;
  message->pPrevious = NULL;
  message->pNext = NULL;

}



void* makeAllNULLMailbox(Mailbox* mBox){
  if(mBox == NULL || mBox == FAIL){
    return FAIL
  }
  mBox->pHead = NULL;
  mBox->pTail = NULL;
  mBox->nDataSize = NULL;
  mBox->nMaxMessages = NULL;
  mBox->nMessages = NULL;
  mBox->nBlockedMsg = NULL;
  return OK;
}

void* MakeAllNULLmsg(msg* message){

  message->pData = NULL;
  message->pBlock = NULL;
  message->pPrevious = NULL;
  message->pnext = NULL;
  message->myMailBox = NULL;
  return OK;
}



int size(Mailbox** mBox){
  int size = 0;
  Mailbox* tempMBox = *mBox;
  msg* tempMSG = tempMBox->pHead;
  if(tempMBox->pHead == NULL && tempMBox->pTail == NULL){
    return size;
  }

  while(tempMSG != NULL){
    tempMSG = tempMSG->pNext;
    size++;
  }
  return size;
}

int isFull(Mailbox** mBox){
  Mailbox* tempMBox = *mBox;
  if(tempMBox->nMaxMessages == size(**mBox){
    return 1;
  }
  return 0;
}



void* enque(Mailbox** mBox, msg newMessage){
  Mailbox* tempMBox = *mBox;
  msg* tempMSG = tempMBox->pHead;
  if(isFull(**mBox)){ //CHECK IF QUE IS FULL
    printf("QUE IS FULL\n", );
    return FAIL;
  }

  if(tempMBox->pHead == NULL && tempMBox->pHead == NULL){   //QUE IS EMPTY
    printf("QUE IS EMPTY\n", );

    if(newMessage == NULL){ //CHECK IF QUE IS FULL
      printf("MESSAGE IS NULL\n", );
      return FAIL;
    }
    tempMBox->pHead = newMessage;
    tempMBox->pPrevious = newMessage;
    tempMBox->nMessages = nMessages + 1;
    return OK;
  }
  else{

    tempMSG = tempMBox->pTail;
    tempMSG->pNext = newMessage;
    newMessage->pPrevious = tempMSG;
    tempMBox->pTail = message;

    tempMBox->nMessages = tempMBox->nMessages + 1;
    // while(tempMSG->pNext != NULL){
    //   tempMSG = tempMSG->pNext;
    // }
    // tempMSG->pNext = newMessage;
    // newMessage->pPrevious = tempMSG;
    // tempMSG->tail = newMessage;
    return OK
  }
}

msg deque(mailbox** mBox){
  mailbox* tempMBox = *mBox;
  tempMBox->pHead = tempMBox->pHead->pNext;
  tempMBox->pHead->pPrevious->pNext = NULL;

  msg* tempMessage = tempMBox->pHead->pPrevious;
  tempMBox->pHead->pPrevious = NULL;
  tempMBox->nMessages = nMessages - 1;
  //MakeAllNULLmsg(tempMessage);
  //free(tempMessage);
  return tempMessage;
}



msg deque(Mailbox** mBox, msg* message){
  mailbox* tempMBox = *mBox;
  msg * tempMSG = message;

  if (tempMSG->pPrevious != NULL){
    tempMSG->pPrevious->pNext = tempMSG->pNext;
  }
  if(tempMSG->pNext != NULL){
    tempMSG->pNext->pPrevious = tempMSG->pPrevious;
  }
  else{
    if(tempMSG->pPrevious == NULL){
      tempMBox->pHead = tempMSG->pNext;
    }
    if(tempMSG->pPrevious ==NULL){
      tempMBox->pTail = tempMSG->pPrevious;
    }
  }
  tempMBox->pPrevious = NULL;
  tempMBox->pNext = NULL;
  return tempMBox;

}
