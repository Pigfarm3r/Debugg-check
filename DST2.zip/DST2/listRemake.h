
#include <stdio.h>
//#include "kernel_functions_march_2019.h"


listobj* safeAllocNode(){                   //ALLOCATE MEMORY OF NODE
  struct l_obj *node = NULL;
  node = malloc(sizeof(struct l_obj));
  if(node == NULL){
    printf("MALLOC IN NODE FAILED!\n");
    return FAIL;
  }
  return node;
}







list* safeAllocList(){
  struct _list *list = NULL;
  list = malloc(sizeof(struct _list));
  if(list == NULL){
    printf("MALLOC IN LIST FAILED!\n");
    return FAIL;
  }
  return list;
}








listobj* createNode(listobj *pNextArg, listobj *pPreviousArg, msg *pMessageArg, uint nTCnt, TCB *pTaskArg){
  listobj *node = safeAllocNode();
  if(node == NULL){
    return FAIL;
  }
  node->pNext = pNextArg;
  node->pPrevious = pPreviousArg;
  node->pMessage = pMessageArg;
  node->nTCnt = nTCnt;
  node->pTask = pTaskArg;
  return node;
}











list* createList(){
  list *list = safeAllocList();
  if(list == NULL){
    return FAIL;
  }
  list->pHead = NULL;
  list->pTail = NULL;
  return list;
}










void* insertSorted(struct _list **list, listobj *node){
  struct _list *tempList = *list;
  listobj *tempNode = tempList->pHead;

  if (tempList->pHead == NULL && tempList->pTail == NULL) { //If list is empty

    if(node == FAIL || node == NULL){                        //If something went wrong before
      return FAIL;
    }

    tempList->pHead = node;
    tempList->pTail = node;
    node->pNext = NULL;
    node->pPrevious = NULL;
  }

  if(tempList->pHead == tempList->pTail  && tempList->pTail != NULL){         //If there is only one node in the list

    if(tempNode->pTask->Deadline >= node->pTask->Deadline ){

      tempNode->pNext = node;
      node->pPrevious = tempNode;
      tempList->pTail = node;
    }
    else{

      tempNode->pPrevious = node;
      node->pNext = tempNode;
      tempList->pHead = node;
    }
  }


  else{
    while(tempNode->pNext !=NULL){                                                  //If there is more than one node in the list

      if(tempNode->pTask->Deadline >= node->pTask->Deadline && tempNode->pNext->pTask->Deadline <= node->pTask->Deadline){

        node->pNext = tempNode->pNext;
        node->pPrevious = tempNode;
        tempNode->pNext = node;
        node->pNext->pPrevious = node;
        break;
      }
      else{
        tempNode = tempNode->pNext;
      }
    }
  }
}

















listobj* extract(list** listInput, listobj* objRemove){

  list* listCopy = *listInput;
  listobj* bojRemoveCopy = objRemove;


  if(listCopy->pHead == bojRemoveCopy && bojRemoveCopy->pPrevious == NULL){                          //If objRemove is in the head

    listCopy->pHead = bojRemoveCopy->pNext;
    listCopy->pHead->pPrevious = NULL;
    bojRemoveCopy->pNext = NULL;

    return bojRemoveCopy;
  }


  if(listCopy->pTail == bojRemoveCopy && bojRemoveCopy->pNext == NULL){                                   //If objRemove is in the tail

    listCopy->pTail = bojRemoveCopy->pPrevious;
    bojRemoveCopy->pPrevious = NULL;
    listCopy->pTail->pNext = NULL;

    return bojRemoveCopy;

  }


  if(bojRemoveCopy->pNext != NULL && bojRemoveCopy->pPrevious != NULL){                                              //If objRemove is in the middle of the list

    bojRemoveCopy->pPrevious->pNext = bojRemoveCopy->pNext;
    bojRemoveCopy->pNext->pPrevious = bojRemoveCopy->pPrevious;
    bojRemoveCopy->pNext = NULL;
    bojRemoveCopy->pPrevious = NULL;

    return bojRemoveCopy;
  }


}
