
#include <stdio.h>
//#include "kernel_functions_march_2019.h"





void* safeAllocMailbox(){
  mailbox* mBox = NULL;
  mBox = malloc(sizeof(mailbox));
  if(mBox == NULL){
    isr_off();                      //DISABLE INTERUPS
    printf("MALLOC IN MAILBOX FAILED\n");
    isr_on();                       //ENABLE INTERUPS
    return FAIL;
  }
  return mBox;
}

void* safeAllocMessage(){
  msg* message = NULL;
  message = malloc(sizeof(message));
  if(message == NULL){
    isr_off();                      //DISABLE INTERUPS
    printf("MALLOC IN MESSAGE FAILED\n");
    isr_on();                       //ENABLE INTERUPS
    return FAIL;
  }
  return message;
}






void* createMailbox(msg* head, msg* tail, int dataSize, int maxMessages, int blockedMsg){

  mailbox* mBox = safeAllocMailbox();
  if(mBox == NULL || mBox == FAIL){
    isr_off();                      //DISABLE INTERUPS
    printf("SOMETHING FAILED IN CREATEMAILBOX\n");
    isr_on();                       //ENABLE INTERUPS
    return FAIL;
  }
  mBox->pHead = head;
  mBox->pTail = tail;
  mBox->nDataSize = dataSize;
  mBox->nMaxMessages = maxMessages;
  mBox->nMessages = 0;
  mBox->nBlockedMsg = blockedMsg;

  return mBox;
}










void* createMSG(char* pDataInput, exception statusInput, listobj* pBlockInput, msg* pPreviousInput, msg* pNextInput, mailbox* myMailBoxInput){
  struct msgobj* message = safeAllocMessage();
  if(message == NULL || message == FAIL){
    isr_off();                      //DISABLE INTERUPS
    printf("SOMETHING FAILED IN CREATEMSG\n");
    isr_on();                       //ENABLE INTERUPS
    return FAIL;
  }

  message->pData = pDataInput;
  message->Status = statusInput;
  message->pBlock = pBlockInput;
  message->pPrevious = pPreviousInput;
  message->pNext = pNextInput;
  message->myMailbox = myMailBoxInput;

  return message;
}


exception makeAllNULLMailbox(mailbox* mBox){
  if(mBox == NULL || mBox == FAIL){
    return FAIL;
  }

  mBox->pHead = NULL;
  mBox->pTail = NULL;
  mBox->nDataSize = NULL;
  mBox->nMaxMessages = NULL;
  mBox->nMessages = NULL;
  mBox->nBlockedMsg = NULL;
  return OK;

}





exception MakeAllNULLmsg(msg* message){
  
  if(message == NULL || message == FAIL){
    return FAIL;
  }

  message->pData = NULL;
  message->Status = NULL;
  message->pBlock = NULL;
  message->pPrevious = NULL;
  message->pNext = NULL;
  message->myMailbox = NULL;
  return OK;


}



int size(mailbox** mBox){
  mailbox* mBoxCopy = *mBox;
  int size = mBoxCopy->nMessages;
  return size;
}




int isFull(mailbox** mBox){
  mailbox* mBoxCopy = *mBox;
  if(mBoxCopy->nMaxMessages == mBoxCopy->nMessages){
    return 1;
  }
  return 0;
}



int isEmpty(mailbox** mBox){
  mailbox* mBoxCopy = *mBox;
  if(mBoxCopy->nMessages == 0){
    return 1;
  }
  return 0;
}








exception enque(mailbox** mBox, msg* newMessage){
  
  //pPrev g�r mot tail 
  //PnNext g�r mot head
  mailbox* tempMBox = *mBox;
  msg* tempMSG = tempMBox->pHead;

  if(isFull(&tempMBox) == 1){                          //If que is full
    isr_off();                                         //DISABLE INTERUPS
    printf("QUE IS FULL\n");
    isr_on();                                         //ENABLE INTERUPS
    return FAIL;
  }

  if(isEmpty(&tempMBox) == 1){                           //If que is empty
    isr_off();                                         //DISABLE INTERUPS
    printf("QUE IS EMPTY\n");
    isr_on();

    tempMBox->pHead = newMessage;
    tempMBox->pTail = newMessage;
    
  }

  else{                                               //Adding messages to que
  
    tempMSG->pNext = newMessage;
    newMessage->pPrevious = tempMSG;
    tempMBox->pHead = newMessage;
    tempMBox->nMessages = (tempMBox->nMessages) + 1;

    return OK;

  }

}









void* deque(mailbox** mBox, msg* removeMessage){

  mailbox* tempMBox = *mBox;
  msg * tempMSG = removeMessage;

  if (isEmpty(&tempMBox) == 1) {                               //If que is empty

    isr_off();                            //DISABLE INTERUPS
    printf("MAILBOX IS EMPTY\n");
    isr_on();                             //ENABLE INTERUPS

    return FAIL;
  }

  if(size(&tempMBox) == 1){                            //Only one message in que

    tempMBox->pHead = NULL;
    tempMBox->pTail = NULL;
    tempMBox->nMessages = 0;

    return removeMessage;

  }

  else{                                           //Multiple messages in the que


    if(tempMBox->pHead == removeMessage){                                //Message is in Head
      removeMessage->pNext->pPrevious = NULL;
      tempMBox->pHead = tempMBox->pHead->pNext;
      removeMessage->pNext = NULL;

      return removeMessage;
    }

    if(tempMBox->pTail == removeMessage){                               //Message is in Tail
      removeMessage->pPrevious->pNext = NULL;
      tempMBox->pTail = tempMBox->pTail->pPrevious;
      removeMessage->pPrevious = NULL;

      return removeMessage;
    }

    else{                               //Message is in the middle of the que

      removeMessage->pPrevious->pNext = removeMessage->pNext;
      removeMessage->pNext->pPrevious = removeMessage->pPrevious;
      removeMessage->pNext = NULL;
      removeMessage->pPrevious = NULL;

      return removeMessage;
    }
  }
}
