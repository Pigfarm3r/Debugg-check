#include "kernel_functions.c" 

void main(){
  SystemInit();
  SysTick_Config(1000000);
  SCB->SHP[((uint32_t)(SysTick_IRQn) & 0xF) - 4] = (0xE0);
  isr_off();

  init_kernel();

  //CREATE TASCK AND MAILBOXES

  run();

}
