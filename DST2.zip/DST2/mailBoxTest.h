
#include <stdlib.h>  /* for using the functions calloc, free */
#include <string.h>  /* for using the function memcpy        */
#include <stdio.h>
#include <limits.h>  /* for using the constant UINT_MAX      */

#define CONTEXT_SIZE    8   /*  for the 8 registers: r4 to r11   */
#define STACK_SIZE      100 /*  about enough space for the stack */


#define TRUE    1
#define FALSE   !TRUE

#define RUNNING 1
#define INIT    !RUNNING

#define FAIL    0
#define SUCCESS 1
#define OK              1

#define DEADLINE_REACHED        0
#define NOT_EMPTY               0

#define SENDER          +1
#define RECEIVER        -1


typedef int             exception;
typedef int             bool;
typedef unsigned int    uint;
typedef int 			action;

struct  l_obj;         // Forward declaration

// Task Control Block, TCB.  Modified on 24/02/2019
typedef struct
{
        //uint    Context[CONTEXT_SIZE];
        uint    *SP;                      //Stack
        uint    R4toR11[CONTEXT_SIZE];
        //void    (*LR)();
        void    (*PC)();      //point counter
        uint    SPSR;
        uint    StackSeg[STACK_SIZE];
        uint    Deadline;
} TCB;


// Message items
typedef struct msgobj {
        char            *pData;
        exception       Status;
        struct l_obj    *pBlock;
        struct msgobj   *pPrevious;
        struct msgobj   *pNext;
} msg;

// Mailbox structure
typedef struct {
        msg             *pHead;
        msg             *pTail;
        int             nDataSize;
        int             nMaxMessages;
        int             nMessages;
        int             nBlockedMsg;
} mailbox;

// Generic list item
typedef struct l_obj {
         TCB            *pTask;
         uint           nTCnt;
         msg            *pMessage;
         struct l_obj   *pPrevious;
         struct l_obj   *pNext;
} listobj;


// Generic list
typedef struct _list {
         listobj        *pHead;
         listobj        *pTail;
} list;



mailbox* safeAllocMailbox(){
  mailbox* mBox = NULL;
  mBox = malloc(sizeof(mailbox));
  if(mBox == NULL){
    printf("MALLOC IN MAILBOX!\n");
    return FAIL;
  }
  return mBox;
}
msg* safeAllocMessage(){
  msg* msg = NULL;
  msg = malloc(sizeof(msg));
  if(msg == NULL){
    printf("MALLOC IN MESSAGE!\n");
    return FAIL;
  }
  return msg;
}

mailbox* createMailbox(msg* head, msg* tail, int dataSize, int maxMessages, int messages, int blockedMsg){
  mailbox *mBox = safeAllocMailbox();
  if(mBox == NULL || mBox == FAIL){
    return FAIL;
  }
  mBox->pHead = head;                                   //Head in the data struct
  mBox->pTail = tail;                                   //Tail in the data struct
  mBox->nDataSize = dataSize;
  mBox->nMaxMessages = maxMessages;
  mBox->nMessages = messages;
  mBox->nBlockedMsg = blockedMsg;



  return mBox;
}
msg* createMSG(msg* pNextArg, msg* pPreviousArg, listobj *pBlockArg, exception StatusArg, char *pDataArg){     //maybe add ,exception statusInput
  msg* message = safeAllocMessage();
  if(message == NULL){
    return FAIL;
  }
  message->pNext = pNextArg;
  message->pPrevious = pPreviousArg;
  message->pBlock = pBlockArg;
  message->Status = StatusArg;
  message->pData = pDataArg;

  return message;
}
int size(mailbox** mBox){
  int size = 0;
  mailbox* tempMBox = *mBox;
  msg* tempMSG = tempMBox->pHead;
  if(tempMBox->pHead == NULL && tempMBox->pTail == NULL){
    return size;
  }

  while(tempMSG != NULL){
    tempMSG = tempMSG->pNext;
    size++;
  }
  return size;
}
int isFull(mailbox** mBox){
  mailbox* tempMBox = *mBox;
  if(tempMBox->nMaxMessages == NULL){
    printf("nMaxMessages is NULL\n");
    return 0;
  }
  if(tempMBox->nMaxMessages == size(mBox)){
    return 1;
  }
  return 0;
}

int enque(mailbox** mBox, msg* newMessage){
  mailbox* tempMBox = *mBox;
  msg* tempMSG = tempMBox->pHead;
  if(isFull(mBox) == 1){ //CHECK IF QUE IS FULL
    printf("QUE IS FULL\n");
    return FAIL;
  }

  if(tempMBox->pHead == NULL && tempMBox->pHead == NULL){   //QUE IS EMPTY
    printf("QUE IS EMPTY\n");

    // if(newMessage == NULL){ //CHECK IF QUE IS FULL
    //   printf("MESSAGE IS NULL\n");
    //   return FAIL;
    // }
    tempMBox->pHead = newMessage;
    tempMBox->pTail = newMessage;
    return OK;
  }
  else{

    tempMSG = tempMBox->pTail;
    tempMSG->pNext = newMessage;
    newMessage->pPrevious = tempMSG;
    tempMBox->pTail = newMessage;
    // while(tempMSG->pNext != NULL){
    //   tempMSG = tempMSG->pNext;
    // }
    // tempMSG->pNext = newMessage;
    // newMessage->pPrevious = tempMSG;
    // tempMSG->tail = newMessage;
    return OK;
  }
}
void printMailbox(mailbox** mBox){
  mailbox* tempMBox = *mBox;
  if(tempMBox->pHead == NULL && tempMBox->pTail == NULL){
    printf("Mailbox is empty!\n");
    return;
  }
  msg* tempMSG = tempMBox->pHead;
  while(tempMSG->pNext != NULL){
    printf("pData: %c     Status: %d",tempMSG->pData,tempMSG->Status);
  }

}
