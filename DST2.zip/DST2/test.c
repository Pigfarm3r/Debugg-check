#include <stdlib.h>  /* for using the functions calloc, free */
#include <string.h>  /* for using the function memcpy        */
#include <limits.h>  /* for using the constant UINT_MAX      */
#include "mailBoxTest.h"
int main(void){
  mailbox* mailBox = createMailbox(NULL,NULL, 0, 0, 0, 0);
  msg* message = createMSG(NULL,NULL,NULL,0,NULL);
  enque(&mailBox,message);
  printMailbox(&mailBox);
}
