#include "kernel_functions_march_2019.h"
int Ticks;                                        //The global tick counter               (global clock)
int KernelMode;                                   //The Mode the kernel is in. Can be either INIT or RUNNING
TCB *PreviousTask, *NextTask;                     //PreviousTask is the task that the program run before. NextTask is the task that should be running right now
list *ReadyList, *WaitingList, *TimerList;        //

