

#include <stdlib.h>  /* for using the functions calloc, free */
#include <string.h>  /* for using the function memcpy        */
#include <limits.h>  /* for using the constant UINT_MAX      */

#define CONTEXT_SIZE    8   /*  for the 8 registers: r4 to r11   */ 
#define STACK_SIZE      100 /*  about enough space for the stack */


#define TRUE    1
#define FALSE   !TRUE

#define RUNNING 1
#define INIT    !RUNNING

#define FAIL    0
#define SUCCESS 1
#define OK              1

#define DEADLINE_REACHED        0
#define NOT_EMPTY               0

#define SENDER          +1
#define RECEIVER        -1


typedef int             exception;
typedef int             bool;
typedef unsigned int    uint;
typedef int 			action;

struct  l_obj;         // Forward declaration
struct m_box;

// Task Control Block, TCB.  Modified on 24/02/2019
typedef struct
{
        //uint    Context[CONTEXT_SIZE];        
        uint    *SP;
        uint    R4toR11[CONTEXT_SIZE];
        //void    (*LR)();
        void    (*PC)();
        uint    SPSR;     
        uint    StackSeg[STACK_SIZE];
        uint    Deadline;
} TCB;


// Message items
typedef struct msgobj {
        char            *pData;
        exception       Status;
        struct l_obj    *pBlock;
        struct msgobj   *pPrevious;
        struct msgobj   *pNext;
        struct m_box  *myMailbox;
} msg;

// Mailbox structure
typedef struct m_box{
        msg             *pHead;
        msg             *pTail;
        int             nDataSize;        //Size of one message in the mailbox 
        int             nMaxMessages;    //Max number of messages in the mailbox
        int             nMessages;        //Current amount of messages in the mailbox
        int             nBlockedMsg;     ///Amount of messages that have a pointer
} mailbox;



// Generic list item
typedef struct l_obj {
         TCB            *pTask;
         uint           nTCnt;          //Sleeptime
         msg            *pMessage;
         struct l_obj   *pPrevious;
         struct l_obj   *pNext;
} listobj;


// Generic list
typedef struct _list {
         listobj        *pHead;
         listobj        *pTail;
} list;


// Function prototypes
int Ticks;                                        //The global tick counter               (global clock)
int KernelMode;                                   //The Mode the kernel is in. Can be either INIT or RUNNING
TCB *PreviousTask, *NextTask;                     //PreviousTask is the task that the program run before. NextTask is the task that should be running right now
list *ReadyList, *WaitingList, *TimerList;        //    

// Task administration
int             init_kernel(void);
exception	create_task( void (* body)(), uint d );
void            terminate( void );
void            run( void );

// Communication
mailbox*	create_mailbox( uint nMessages, uint nDataSize );
int             no_messages( mailbox* mBox );

exception       send_wait( mailbox* mBox, void* pData );
exception       receive_wait( mailbox* mBox, void* pData );

exception	send_no_wait( mailbox* mBox, void* pData );
int             receive_no_wait( mailbox* mBox, void* pData );


// Timing
exception	wait( uint nTicks );
void            set_ticks( uint no_of_ticks );
uint            ticks( void );
uint		deadline( void );
void            set_deadline( uint nNew );

//Interrupt and context switch
extern void     isr_off(void);
extern void     isr_on(void);

extern void     SwitchContext( void );	
                   /* Stores stack frame in stack of currently running task, and the
                    * remaining registers in its TCB
                    * Loads stack frame from stack of RunningTask, and the
                    * remaining registers from its TCB
                    */
                                        
extern void     LoadContext_In_Run( void );
                   /* To be used on the last line of the C function run() */

extern void     switch_to_stack_of_next_task( void );
                   /* To be used inside the C function terminate() */
                     
extern void     LoadContext_In_Terminate( void );
                   /* To be used on the last line of the C function terminate() */
//#include "kernel_functions_march_2019.h"





listobj* safeAllocNode(){                   //ALLOCATE MEMORY OF NODE
  struct l_obj *node = NULL;
  node = malloc(sizeof(struct l_obj));
  if(node == NULL){
    printf("MALLOC IN NODE FAILED!\n");
    return FAIL;
  }
  return node;
}







list* safeAllocList(){
  list *pList = NULL;
  pList = (list*)calloc(1,sizeof(list));
  if(pList == NULL){
    printf("MALLOC IN LIST FAILED!\n");
    return FAIL;
  }
  return pList;
}








listobj* createNode( msg *pMessageArg, uint nTCnt, TCB *pTaskArg){
  listobj *node = safeAllocNode();
  if(node == NULL){
    return FAIL;
  }
  //node->pNext = pNextArg;
  //node->pPrevious = pPreviousArg;
  node->pMessage = pMessageArg;
  node->nTCnt = nTCnt;
  node->pTask = pTaskArg;
  return node;
}











list* createList(){
  list *pList = safeAllocList();
  if(pList == NULL){
    return FAIL;
  }
  pList->pHead = NULL;
  pList->pTail = NULL;
  return pList;
}










void insertSorted(struct _list **plist, listobj *newNode){
  
  struct _list *thisList = *plist;
  listobj *nodeInList = thisList->pHead;
  

  
  
  if (thisList->pHead == NULL && thisList->pTail == NULL) { //If list is empty

    if(newNode == FAIL || newNode == NULL){                        //If something went wrong before
      return;
    }

    thisList->pHead = newNode;
    thisList->pTail = newNode;
    newNode->pNext = newNode;
    newNode->pPrevious = newNode;
    return;
  }

  if(thisList->pHead == thisList->pTail && thisList->pTail != NULL){         //If there is only one node in the list

    if(nodeInList->pTask->Deadline >= newNode->pTask->Deadline ){            //Place new node before old node in list
      
      newNode->pNext = nodeInList;
      newNode->pPrevious = NULL;
      nodeInList->pPrevious = newNode;
      nodeInList->pNext = NULL;
      
      thisList->pHead = newNode;
      thisList->pTail = nodeInList;
      
        
      return;
      
    }
    else{                                                                       //Place new node AFTER the node in the list

     nodeInList->pNext = newNode;
     nodeInList->pPrevious = NULL;
     newNode->pPrevious = nodeInList;
     newNode->pNext = NULL;
     
     thisList->pHead = nodeInList;
     thisList->pTail = newNode;
     
     return;
     
    }
  }


  else{
     if(thisList->pHead->pTask->Deadline >= newNode->pTask->Deadline){                 //If the new node should be put in head
      
       thisList->pHead->pPrevious = newNode;
       newNode = thisList->pHead;
       thisList->pHead = newNode;
       
       return;  
      }
     
     if(thisList->pTail->pTask->Deadline <= newNode->pTask->Deadline){                 //If the node should be put in tail
       
       thisList->pTail->pNext = newNode;
       newNode->pPrevious = thisList->pTail;
       thisList->pTail = newNode;
       
        return;  
      }
    while(nodeInList !=NULL){                                                  //If there is more than one node in the list
 
      if(nodeInList->pTask->Deadline >= newNode->pTask->Deadline ){
        
        newNode->pNext = nodeInList;
        newNode->pPrevious = nodeInList->pPrevious;
        nodeInList->pPrevious->pNext = newNode;
        nodeInList->pPrevious = newNode;
        
  
        return;
      }
      else{
        nodeInList = nodeInList->pNext;
      }
    }
  }
}

















listobj* extract(list** listInput, listobj* objRemove){

  list* thisList = *listInput;
  


  if(thisList->pHead == objRemove){                          //If objRemove is in the head
    
    thisList->pHead = thisList->pHead->pNext;
    
    thisList->pHead->pPrevious = NULL;
    objRemove->pNext = NULL;
    objRemove->pPrevious = NULL;
    
    return objRemove;
  }


  if(thisList->pTail == objRemove){                                   //If objRemove is in the tail
    
    thisList->pTail = objRemove->pPrevious;
    
    thisList->pTail->pNext = NULL;
    objRemove->pNext = NULL;
    objRemove->pPrevious = NULL;
   
    return objRemove;
  }


  if(objRemove->pNext != NULL && objRemove->pPrevious != NULL){                                              //If objRemove is in the middle of the list
    
    objRemove->pPrevious->pNext = objRemove->pNext;
    objRemove->pNext->pPrevious = objRemove->pPrevious;
    
    objRemove->pNext = NULL;
    objRemove->pPrevious = NULL;
    
    return objRemove;
  }
}



































void* safeAllocMailbox(){
  mailbox* mBox = NULL;
  mBox = malloc(sizeof(mailbox));
  if(mBox == NULL){
    isr_off();                      //DISABLE INTERUPS
    printf("MALLOC IN MAILBOX FAILED\n");
    isr_on();                       //ENABLE INTERUPS
    return FAIL;
  }
  return mBox;
}

void* safeAllocMessage(){
  msg* message = NULL;
  message = malloc(sizeof(message));
  if(message == NULL){
    isr_off();                      //DISABLE INTERUPS
    printf("MALLOC IN MESSAGE FAILED\n");
    isr_on();                       //ENABLE INTERUPS
    return FAIL;
  }
  return message;
}






void* createMailbox(msg* head, msg* tail, int dataSize, int maxMessages, int blockedMsg){

  mailbox* mBox = safeAllocMailbox();
  if(mBox == NULL || mBox == FAIL){
    isr_off();                      //DISABLE INTERUPS
    printf("SOMETHING FAILED IN CREATEMAILBOX\n");
    isr_on();                       //ENABLE INTERUPS
    return FAIL;
  }
  mBox->pHead = head;
  mBox->pTail = tail;
  mBox->nDataSize = dataSize;
  mBox->nMaxMessages = maxMessages;
  mBox->nMessages = 0;
  mBox->nBlockedMsg = blockedMsg;

  return mBox;
}










msg* createMSG(char* pDataInput, exception statusInput, listobj* pBlockInput, msg* pPreviousInput, msg* pNextInput, mailbox* myMailBoxInput){
  msg* message = safeAllocMessage();
  if(message == NULL || message == FAIL){
    isr_off();                      //DISABLE INTERUPS
    printf("SOMETHING FAILED IN CREATEMSG\n");
    isr_on();                       //ENABLE INTERUPS
    return FAIL;
  }

  message->pData = pDataInput;
  message->Status = statusInput;
  message->pBlock = pBlockInput;
  message->pPrevious = pPreviousInput;
  message->pNext = pNextInput;
  message->myMailbox = myMailBoxInput;

  return message;
}


exception makeAllNULLMailbox(mailbox* mBox){
  if(mBox == NULL || mBox == FAIL){
    return FAIL;
  }

  mBox->pHead = NULL;
  mBox->pTail = NULL;
  mBox->nDataSize = NULL;
  mBox->nMaxMessages = NULL;
  mBox->nMessages = NULL;
  mBox->nBlockedMsg = NULL;
  return OK;

}





exception MakeAllNULLmsg(msg* message){

  if(message == NULL || message == FAIL){
    return FAIL;
  }

  message->pData = NULL;
  message->Status = NULL;
  message->pBlock = NULL;
  message->pPrevious = NULL;
  message->pNext = NULL;
  message->myMailbox = NULL;
  return OK;


}



int size(mailbox** mBox){
  mailbox* mBoxCopy = *mBox;
  int size = mBoxCopy->nMessages;
  return size;
}




int isFull(mailbox** mBox){
  mailbox* mBoxCopy = *mBox;
  if(mBoxCopy->nMaxMessages == mBoxCopy->nMessages){
    return 1;
  }
  return 0;
}



int isEmpty(mailbox** mBox){
  mailbox* mBoxCopy = *mBox;
  if(mBoxCopy->nMessages == 0){
    return 1;
  }
  return 0;
}








exception enque(mailbox** mBox, msg* newMessage){

  //pPrev g?r mot tail
  //PnNext g?r mot head
  mailbox* tempMBox = *mBox;
  msg* tempMSG = tempMBox->pHead;

  if(isFull(&tempMBox) == 1){                          //If que is full
    isr_off();                                         //DISABLE INTERUPS
    printf("QUE IS FULL\n");
    isr_on();                                         //ENABLE INTERUPS
    return FAIL;
  }

  if(isEmpty(&tempMBox) == 1){                           //If que is empty
    isr_off();                                         //DISABLE INTERUPS
    printf("QUE IS EMPTY\n");
    isr_on();

    tempMBox->pHead = newMessage;
    tempMBox->pTail = newMessage;
    newMessage->myMailbox = tempMBox;
    return OK;
  }

  else{                                               //Adding messages to que

    tempMSG->pNext = newMessage;
    newMessage->pPrevious = tempMSG;
    tempMBox->pHead = newMessage;
    tempMBox->nMessages = (tempMBox->nMessages) + 1;
    newMessage->myMailbox = tempMBox;

    return OK;

  }
  return FAIL;

}









msg* deque(mailbox** mBox, msg* removeMessage){

  mailbox* tempMBox = *mBox;
 // msg * tempMSG = removeMessage;

  if (isEmpty(&tempMBox) == 1) {                               //If que is empty

    isr_off();                            //DISABLE INTERUPS
    printf("MAILBOX IS EMPTY\n");
    isr_on();                             //ENABLE INTERUPS

    return NULL;
  }

  if(size(&tempMBox) == 1){                            //Only one message in que

    tempMBox->pHead = NULL;
    tempMBox->pTail = NULL;
    tempMBox->nMessages = 0;

    return removeMessage;

  }

  else{                                           //Multiple messages in the que


    if(tempMBox->pHead == removeMessage){                                //Message is in Head
      removeMessage->pNext->pPrevious = NULL;
      tempMBox->pHead = tempMBox->pHead->pNext;
      removeMessage->pNext = NULL;

      return removeMessage;
    }

    if(tempMBox->pTail == removeMessage){                               //Message is in Tail
      removeMessage->pPrevious->pNext = NULL;
      tempMBox->pTail = tempMBox->pTail->pPrevious;
      removeMessage->pPrevious = NULL;

      return removeMessage;
    }

    else{                               //Message is in the middle of the que

      removeMessage->pPrevious->pNext = removeMessage->pNext;
      removeMessage->pNext->pPrevious = removeMessage->pPrevious;
      removeMessage->pNext = NULL;
      removeMessage->pPrevious = NULL;

      return removeMessage;
    }
  }
}



int checkIfNULL(list** pList){
  list* pListCopy = *pList;
  if(pListCopy == NULL){
    return 1;
  }
  return 0;
}






















/*WRITE ALL THE FUNCTIONS*/
void Task_idle(){

while(1);
}



exception init_kernel(){
  exception status;
  set_ticks(0);
  ReadyList = (list*)calloc(1,sizeof(list));
  

//  struct list *executingList = createList();
  WaitingList = (list*)calloc(1,sizeof(list));
  TimerList = (list*)calloc(1,sizeof(list));
  
  if(checkIfNULL(&ReadyList) == 1 || checkIfNULL(&WaitingList) == 1 || checkIfNULL(&TimerList) == 1 ){
    return FAIL;
  }

  create_task(Task_idle, UINT_MAX);
  KernelMode = INIT;
  status = OK;
  return status;
}

exception create_task(void(*taskBody)( ) , unsigned int deadline){
   TCB *new_tcb;                              //CREATE NEW TCB
   new_tcb = (TCB *) calloc (1 , sizeof(TCB) ) ;      //ALLOC MEM FOR TCB

   if(new_tcb == NULL){     //YOU HAVE TO CHECK IF CALLOC WAS SUCESESSFUL OR NOT
     return FAIL;
   }

   new_tcb->PC = taskBody;                    //TCB�s PC point to the task body
   new_tcb->SPSR =  0x21000000;                //Setting a start value to  Process status register
   new_tcb->Deadline = deadline;                    //setting a deadline
   
   new_tcb->StackSeg[STACK_SIZE - 2] = 0x21000000;      //Setting up stack frame
   new_tcb->StackSeg[STACK_SIZE - 3] = (unsigned int) taskBody;    //Setting up stack frame
   new_tcb->SP = &(new_tcb->StackSeg[STACK_SIZE - 9]);            //set TCB�s SP to point to the correct cell in stack segment

   //ADD THE OTHER STUFF


   if(KernelMode == INIT){

     listobj* node = createNode( NULL, 0, new_tcb);


     insertSorted(&ReadyList, node);    //Creates a new object with the right deadline and puts it in the right order in the list
     return OK;
   }
   else{
     isr_off();//DISABLE INTERUPS
     PreviousTask = NextTask;//UPDATE PREVIOUS TASK
     listobj* node = createNode( NULL, 0, new_tcb);
     insertSorted(&ReadyList, node);//INSERT NEW TASK IN READYLIST
     NextTask = ReadyList->pHead->pTask;//UPDATE NextTask
     SwitchContext();//SWITCH Context

   }

   return OK;

 }

 void run(void){
   Ticks = 0;
   KernelMode = RUNNING;//Set KernelMode = RUNNING;

   NextTask = ReadyList->pHead->pTask;

   LoadContext_In_Run();

 }

 void set_deadline(unsigned int d){
    isr_off();
    NextTask->Deadline = d;                        //Set deadline feild in the TCB
    PreviousTask = NextTask;                      //Update PreviousTask

    NextTask = ReadyList->pHead->pTask;    //Update NextTask
    SwitchContext();
 }


 void TimerInt(void){

   Ticks++;

   struct l_obj *tempNodeTimerList = TimerList->pHead;

   struct l_obj *tempNodeWaitingList = WaitingList->pHead;


   while(tempNodeTimerList->pNext != NULL){
     if(tempNodeTimerList->nTCnt == 0 || tempNodeTimerList->pTask->Deadline <= Ticks){      //HAMNAR H� N� JAG G� UR

       if(TimerList->pHead == tempNodeTimerList){
        // changeHead(&TimerList);

         listobj* node = extract(&TimerList,tempNodeTimerList);
         insertSorted(&ReadyList, node);

       }

       listobj* node = extract(&TimerList,tempNodeTimerList);
       insertSorted(&ReadyList, node);
       tempNodeTimerList = tempNodeTimerList->pNext;
     }

   }

   while(tempNodeWaitingList->pNext != NULL){
     if(tempNodeWaitingList->pTask->Deadline <= Ticks){

       if(WaitingList->pHead == tempNodeWaitingList){
         //changeHead(&WaitingList);

         listobj* node = extract(&WaitingList,tempNodeWaitingList);
         msg *message = node->pMessage;
         message = deque(&(message->myMailbox), message);
         MakeAllNULLmsg(message);
         free(message);
         insertSorted(&ReadyList, node);

       }

       listobj* node = extract(&WaitingList,tempNodeWaitingList);
       msg *message = node->pMessage;
       message = deque(&(message->myMailbox), message);
       MakeAllNULLmsg(message);
       free(message);
       insertSorted(&ReadyList, node);


     }


   }



 }
void makeAllNULLlistObj(listobj* obj){
  obj->nTCnt = 0;
  obj->pMessage = NULL;
  obj->pPrevious = NULL;
  obj->pNext = NULL;
}





 void terminate(void){
   isr_off();

  

   listobj* leavingObj = extract(&ReadyList, ReadyList->pHead);    //Remove running task from readylist
   
   makeAllNULLlistObj(leavingObj);
   
   NextTask = ReadyList->pHead->pTask; //ReadyList->pHead = ReadyList->pHead->pNex          //SP I NEXTTASK = 0?
   switch_to_stack_of_next_task(); //switches the stack of the task to be loaded       
   free(leavingObj->pTask);
   free(leavingObj);
   
   
   LoadContext_In_Terminate();    //DENNA FUNGERAR EJ OM MAN STEPAR IN I DETTA 

 }



 mailbox* create_mailbox(uint nof_msg, uint size_of_msg){

   mailbox* mBox = createMailbox(NULL, NULL, size_of_msg, nof_msg, 0);

   if(mBox == NULL  || mBox == FAIL){
     return FAIL;
   }
   return mBox;
 }















exception remove_mailbox(mailbox* mBox){
  if(isEmpty(&mBox) == 1) {  //MAILBOX IS EMPTY
    MakeAllNULLMailbox(mBox);
    free(mBox);//FREE ALL THE SPACE FOR THE MIALBOX
    return OK;
  }
  else{
    return NOT_EMPTY;
  }

}


exception send_wait( mailbox* mBox, void* Data){
  isr_off();        //DISABLE INTERUPS


  if(mBox->pHead->Status == -1){                          //  receiving task is waiting
    memcpy( mBox->pHead->pData, Data , mBox->nDataSize); //COPY SENDERS DATA TO DATA AREA    //MAYBE OTHER WAY AROUND
    msg* MSGobj = deque(&mBox, mBox->pHead);
    PreviousTask = NextTask;                              //UPDATE PREVIOUS TASK
    listobj* node = MSGobj->pBlock;

    node = extract(&WaitingList, node);

    //listobj* node = createNode(NULL, NULL, msg *pMessageArg, uint nTCnt, TCB *pTaskArg);


    insertSorted(&ReadyList, node);                               //INSERT NEW TASK IN READYLIST
    NextTask = ReadyList->pHead->pTask;                           //UPDATE NextTask

  }
  else{

    msg* MSGobj = createMSG(NULL, NULL, NULL, NULL, NULL, NULL);   //ALLOC A MESSAGE STRUCT
    MSGobj->pData = Data;                                           //Set data pointer
    enque(&mBox, MSGobj);                                           //Add message to mailbox
    PreviousTask = NextTask;                                      //UPDATE PREVIOUS TASK


    listobj* node = ReadyList->pHead;

    while(node->pNext != NULL){
      if(node->pMessage->Status == 1){        //FIND FIRST SENDING TASK
        break;
      }
      node = node->pNext;
    }

    //if(ReadyList->pHead == node){                   //Check if node is in head
      //listobj* extractObj = ReadyList->pHead;
      //ReadyList->pHead = ReadyList->pHead->pNext;
    //}

    //if(ReadyList->pTail == node){                    //Check if node is in tail
      //listobj* extractObj = ReadyList->pTail;
      //ReadyList->pTail = ReadyList->pTail->pPrevious;
    //}

    listobj* leavingObj = extract(&ReadyList,node);
    insertSorted(&WaitingList, leavingObj);         //MOVE SENDING TASK FROM RADYLIST TO WAITINGLIST

    NextTask = ReadyList->pHead->pTask;              //UPDATE NextTask
  }
  SwitchContext();

  if (ReadyList->pHead->pTask->Deadline <= Ticks) {         //Deadline is reached
    isr_off();

    msg* removedMSG = deque(&mBox,mBox->pHead);                            //###REMOVE SEND MESSAGE###
    MakeAllNULLmsg(removedMSG);
    free(removedMSG);
    isr_on();
    return DEADLINE_REACHED;
  }
  else{
    return OK;
  }
}


















exception receive_wait( mailbox* mBox, void* Data){
  isr_off();    //DISABLE INTERUPS

  if(mBox->pHead->Status == 1){                                   //If send message is wating###CHECK ME###
    memcpy( Data, mBox->pHead->pData , mBox->nDataSize);          //Copy senders data to receiving task�s data area

    msg* message = deque(&mBox, mBox->pHead);                     //REMOVE SENDING TASKS MESSAGE FROM MAILBOX

    if(message->pBlock != NULL){                                         //Message is of wait type
      PreviousTask = NextTask;                                  //UPDATE PREVIOUS TASK

      listobj* movingObj = extract(&WaitingList,message->pBlock);         //Extract sending task from waitingList
      insertSorted(&ReadyList, movingObj);                      //place the sending task in ReadyList
      NextTask = ReadyList->pHead->pTask;                //UPDATE NextTask
    }


    else{

      msg* message = deque(&mBox, mBox->pHead);                     //REMOVE SENDING TASKS MESSAGE FROM MAILBOX
      MakeAllNULLmsg(message);
      free(message);
    }
  }

  else{

    msg* MSGobj = createMSG(NULL, NULL, NULL, NULL, NULL, NULL);                  //Allocate a message structure
    enque(&mBox, MSGobj);                                  //Add Message to the Mailbox
    PreviousTask = NextTask;                              //Update PreviousTask



    listobj* node = ReadyList->pHead;                      //Move receiving task from Readylist to Waitinglist
    while(node->pNext != NULL){
      if(node->pMessage->Status == -1){                   //Find the first reciving task in ReadyList
        break;
      }
      node = node->pNext;
    }



    listobj* leavingObj = extract(&ReadyList, node);

    insertSorted(&WaitingList, leavingObj);                 //Insert the task from readyList to the waitingList

    NextTask = ReadyList->pHead->pTask;                    //Update NextTask
  }
  SwitchContext();

  if(ReadyList->pHead->pTask->Deadline <= Ticks){   //If Deadline is reached
    isr_off();
    msg* removedMSG = deque(&mBox, mBox->pHead);   //Remove recived message
    isr_on();
    return DEADLINE_REACHED;
  }
  else{
    return OK;
  }
}














exception send_no_wait( mailbox* mBox, void* Data){
  isr_off();                                                           ///Disable interrupt
  if(mBox->pHead->Status == -1){                                     // If reciving task is waiting

    memcpy( mBox->pHead->pData, Data , mBox->nDataSize);                     //Copy data to recevings tasks data area

    msg* message = deque(&mBox, mBox->pHead);                               //REMOVE SENDING TASKS MESSAGE FROM MAILBOX
    listobj* pBlock = message->pBlock;
    MakeAllNULLmsg(message);
    free(message);

    PreviousTask = NextTask;                                              //Update PreviousTask

    listobj* movingObj = extract(&WaitingList,pBlock);                   //Extract sending task from waitingList
    insertSorted(&ReadyList, movingObj);                                 //place the sending task in ReadyList


    NextTask = ReadyList->pHead->pTask;                //UPDATE NextTask
    SwitchContext();
  }
  else{
    msg* MSGobj = createMSG(NULL, NULL, NULL, NULL, NULL, NULL);                //Allocate memory for message
    MSGobj->pData = Data;                                              //Copy Data to the Message
    if(isFull(&mBox) == 1){                                                  //If mailbox is full
      msg* oldMSG = deque(&mBox,mBox->pHead);                                         //Remove the oldest message
      MakeAllNULLmsg(oldMSG);
      free(oldMSG);                                                   //Free memory

    }
    enque(&mBox,MSGobj);                                     //Add Message to the Mailbox
  }
  return OK;

}




exception receive_no_wait( mailbox* mBox, void* Data){
  isr_off();                                              //Disable interrupts

  if(mBox->pHead->Status == 1){                             //Send Message is waiting

    memcpy( mBox->pHead->pData, Data , mBox->nDataSize);     //Copy senders data to reciving tasks data area

    msg* message = deque(&mBox, mBox->pHead);                    //Remove sending task messege from the mailbox


    listobj* pBlock = message->pBlock;



    if(pBlock != NULL){                                   //Message was of wait type
      PreviousTask = NextTask;                            //Update PreviousTask

      listobj* movingObj = extract(&WaitingList,pBlock);   //Extract sending task from waitingList
      insertSorted(&ReadyList, movingObj);                //place the sending task in ReadyList
      NextTask = ReadyList->pHead->pTask;          //UPDATE NextTask
      SwitchContext();
    }
    else{
      msg* message = deque(&mBox, mBox->pHead);                     //REMOVE SENDING TASKS MESSAGE FROM MAILBOX
      MakeAllNULLmsg(message);
      free(message);
    }
  }
  else{
    return FAIL;
  }

  return OK;
}


exception wait(uint nTicks){
  exception status;
  isr_off();                                            //DISABLE INTERUPS
  PreviousTask = NextTask;                             //Update PreviousTask



  listobj *task = ReadyList->pHead;
  listobj *taskInsert = extract(&ReadyList, task);
  insertSorted(&TimerList, taskInsert);               //Place running task in timer list


  NextTask = ReadyList->pHead->pTask;                //UPDATE NextTask
  SwitchContext();
  if(ReadyList->pHead->pTask->Deadline <= Ticks){
    return DEADLINE_REACHED;
  }
  else{
    return OK;
  }
  return OK;
}




uint ticks(void){
  return Ticks;
}



 void set_ticks( uint nTicks){
   Ticks = nTicks;
 }

