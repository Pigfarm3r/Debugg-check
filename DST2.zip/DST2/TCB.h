#include <stdlib.h>  /* for using the functions calloc, free */
#include <string.h>  /* for using the function memcpy        */
#include <limits.h>  /* for using the constant UINT_MAX      */
#include <stdio.h>
#include "structures.h"



TCB* safeAllocTCB(){                   //ALLOCATE MEMORY OF NODE
  TCB *tcb = NULL;
  tcb = malloc(sizeof( TCB ));
  if(tcb == NULL){
    printf("MALLOC IN NODE FAILED!\n");
    return FAIL;
  }
  return tcb;
}
TCB* createTCB(){
  TCB *tcb = safeAllocTCB();
  if(tcb == NULL){
    return FAIL;
  }
  return tcb;
}
